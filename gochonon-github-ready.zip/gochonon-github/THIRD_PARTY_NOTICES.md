# Third-party notices

## @sohumsuthar/liquid-glass

- Copyright (c) 2026 Sohum Suthar
- License: MIT
- Included files: `vendor/liquid-glass/liquid-glass-core.css`, generated displacement map integration
- Full license: `vendor/liquid-glass/LICENSE`
