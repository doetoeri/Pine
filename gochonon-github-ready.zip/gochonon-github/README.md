# 고촌ON — Apple Responsive System

Figma의 `Responsive Screens (9:6)`를 기준으로 만든 **빌드 없는 정적 웹앱**입니다. 기존 고촌ON 로컬 MVP의 데이터, 화면, 폼, 모달, 로컬 저장 기능은 유지하고 홈과 반응형 내비게이션을 Figma 구조에 맞췄습니다.

## GitHub Pages 배포

1. 이 폴더 안의 파일과 폴더를 GitHub 저장소 **루트**에 그대로 업로드합니다.
2. 저장소의 **Settings → Pages**로 이동합니다.
3. **Deploy from a branch**, `main`, `/ (root)`를 선택합니다.
4. 저장하면 별도의 빌드 없이 `index.html`이 실행됩니다.

## 수정 지점

- 서비스명: `index.html`의 `APP_DEFAULT_CONFIG.serviceName`
- 학교 정보: `APP_DEFAULT_CONFIG.schools`
- Figma 동기화 스타일: `assets/css/figma-sync.css`
- Liquid Glass 연결: `assets/js/liquid-glass-init.js`
- 온보딩 데모: 주소 끝에 `?onboarding=1`

## 데이터

데모 데이터와 사용자의 변경 내용은 브라우저 `localStorage`에 저장됩니다. 실제 운영 전에는 인증과 데이터 저장소를 Firebase, Supabase 등 서버 기반 구조로 교체해야 합니다.

## Liquid Glass preset

`vendor/liquid-glass/liquid-glass-core.css`는 `@sohumsuthar/liquid-glass`의 MIT 라이선스 프리셋을 포함합니다. 이 프로젝트는 효과를 새로 재현하지 않고, 프리셋이 요구하는 레이어와 displacement map을 연결하는 코드만 추가합니다. 원 라이선스는 `vendor/liquid-glass/LICENSE`에 있습니다.
